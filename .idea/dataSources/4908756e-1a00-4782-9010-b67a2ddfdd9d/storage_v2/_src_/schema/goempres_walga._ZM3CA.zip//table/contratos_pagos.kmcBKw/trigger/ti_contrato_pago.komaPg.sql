create definer = lspadmin@localhost trigger ti_contrato_pago
    after insert
    on contratos_pagos
    for each row
    update contratos as c 
set c.monto_pagado = c.monto_pagado + new.monto where c.id = new.contrato_id;

