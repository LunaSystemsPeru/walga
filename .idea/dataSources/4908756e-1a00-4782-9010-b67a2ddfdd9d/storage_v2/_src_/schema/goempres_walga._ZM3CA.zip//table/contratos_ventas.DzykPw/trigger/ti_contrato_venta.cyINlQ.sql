create definer = lspadmin@localhost trigger ti_contrato_venta
    after insert
    on contratos_ventas
    for each row
BEGIN 
update contratos as c 
set c.estado_comprobante = 1 where c.id = new.contrato_id;
END;

