create definer = lspadmin@localhost trigger td_contratos_pagos
    before delete
    on contratos_pagos
    for each row
begin 
update contratos as c 
set c.monto_pagado = c.monto_pagado - old.monto where c.id = old.contrato_id;
END;

