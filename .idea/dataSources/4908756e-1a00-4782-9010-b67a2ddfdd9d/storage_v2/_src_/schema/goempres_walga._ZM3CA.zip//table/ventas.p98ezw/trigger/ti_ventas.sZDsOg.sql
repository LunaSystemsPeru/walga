create definer = root@localhost trigger ti_ventas
    after insert
    on ventas
    for each row
BEGIN
declare _serie varchar(4);
declare _comprobanteid int;
declare _empresaid int;

set _comprobanteid = new.comprobante_id;
set _serie = new.serie;
set _empresaid = new.empresa_id;

update comprobantes_empresas as ce 
set ce.numero = ce.numero+1
where ce.empresa_id = _empresaid and ce.serie = _serie and ce.comprobante_id = _comprobanteid;
END;

